<?php 

$conn = mysqli_connect('localhost', 'root', '', 'monthly_report');
if($conn){
    // echo "Done";
}else{
    echo "Not Done";
}

if(isset($_POST['add_btn'])){
    $days = $_POST['days'];
    $date = $_POST['date'];
    $amount = $_POST['amount'];
    $remarks = $_POST['remarks'];

    if($days == '' || $date == '' || $amount == ''){
        echo "<script>alert('Fields Are Require')</script>";
    }else{
        $query = "INSERT INTO entry_report (days, date, amount, remarks) VALUES ('$days', '$date', '$amount', '$remarks')";

        $insert = mysqli_query($conn, $query);

        if($insert){
            echo "<script>alert('data send Success')</script>";
        } else{
            echo "<script>alert('Data send Fail')</script>";
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <!-- <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    <title>Monthly Reports</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container">
        <div class="btn_div">
            <a href="report.php">Reports</a>
        </div>
        <h2>Monthly Book Entry Reports</h2>
        <hr>
        <form action="" method="POST">
            <input type="number" id="work_days" name="days" placeholder="Enter Working Days"><br></br>
            <input type="date" id="work_date" name="date" placeholder="Enter Working Date"><br></br>
            <input type="number" id="work_amount" name="amount" placeholder="Enter Book Entry Amount"><br></br>
			<input type="text" id="remarks" name="remarks" placeholder="Type Issues"><br></br>
            <button id="add_btn" name="add_btn">Add</button>
        </form>
        <hr>
        <div class="display">
            <h3>Display Reports</h3>
            <p class="total" style="margin:0px; padding-bottom:10px; display: inline-block;">Total Working Days : 
			<?php 
			$total_amount = "SELECT * FROM entry_report";
			$query_total_amount = mysqli_query($conn, $total_amount);
			
			if($total_amount_add = mysqli_num_rows($query_total_amount)){
				echo '<span id="total" name="total">'.$total_amount_add.'</span>'; 
				
			}else{
				echo '<span id="total" name="total">No Data</span>';
			}
				
			?>
			
			</p>
			
			<p style="margin:0px; padding-bottom:10px; color:white; font-weight:700;"> Total Book Entry : <span>0</span> </p>
			
            <table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Working Days</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <?php 
                    $read = "SELECT * FROM entry_report";
                    $query2 = mysqli_query($conn, $read);

                    while($row = mysqli_fetch_array($query2)){ ?>

                    <tr>
                        <td><?php echo $row['id'] ?></td>
                        <td><?php echo $row['days'] ?></td>
                        <td><?php echo $row['date'] ?></td>
                        <td><?php echo $row['amount'] ?></td>
                        <td><?php echo $row['remarks'] ?></td>
                    </tr>


                <?php
                    }
                ?>
                <tbody id="tbody">
                    
                </tbody>
            </table>
        </div>
    </div>
    

    <!-- <script src="app.js"></script> -->
</body>
</html>